public class j{
    public static void main(String[] args) {
        mes();
    }
    static void mes()
    {
        System.out.println("hello mes \n"); 
    mes2();
   }
   static void mes2()
   {
    System.out.println("hello mes 2");
   }
}